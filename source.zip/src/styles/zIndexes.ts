export const zIndexes = {
  building: 20,
  assignNetwork: 50,
  taskWindow: 100,
  modal: 200,
};
export default zIndexes;
