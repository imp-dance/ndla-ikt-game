export type Pos = {
  bottom: number;
  left?: number;
  right?: number;
};
export type Connection = [boolean, boolean, boolean];
