export { default as Window } from './Window'
export { default as Frame1 } from './Frame1'
export { default as Frame2 } from './Frame2'